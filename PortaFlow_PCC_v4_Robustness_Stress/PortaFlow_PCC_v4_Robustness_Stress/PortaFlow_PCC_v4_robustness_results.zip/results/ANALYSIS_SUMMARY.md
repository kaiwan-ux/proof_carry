# PortaFlow PCC v4 Robustness Stress Results

Native rows: 1200
Technical failures: 0

## Overall condition summary

| condition         |   cases |   safe |   rejected |   unsafe |   mean_bytes |   safe_rate |   rejection_rate |   unsafe_rate |   safety_rate |
|:------------------|--------:|-------:|-----------:|---------:|-------------:|------------:|-----------------:|--------------:|--------------:|
| explicit_minimal  |     240 |    222 |          0 |       18 |      817.3   |       0.925 |            0     |         0.075 |         0.925 |
| full_pcc          |     240 |    222 |         18 |        0 |     1609     |       0.925 |            0.075 |         0     |         1     |
| history_inference |     240 |    144 |         96 |        0 |     1037.92  |       0.6   |            0.4   |         0     |         1     |
| hybrid_minimal    |     240 |    180 |         60 |        0 |     1227.12  |       0.75  |            0.25  |         0     |         1     |
| state_only        |     240 |      0 |          0 |      240 |      353.975 |       0     |            0     |         1     |         0     |

## Profile × condition summary

| profile              | condition         |   cases |   safe |   rejected |   unsafe |   safe_rate |   rejection_rate |   unsafe_rate |   safety_rate |
|:---------------------|:------------------|--------:|-------:|-----------:|---------:|------------:|-----------------:|--------------:|--------------:|
| baseline             | explicit_minimal  |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| baseline             | full_pcc          |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| baseline             | history_inference |      48 |     36 |         12 |        0 |       0.75  |            0.25  |         0     |         1     |
| baseline             | hybrid_minimal    |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| baseline             | state_only        |      48 |      0 |          0 |       48 |       0     |            0     |         1     |         0     |
| noise_duplicate      | explicit_minimal  |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| noise_duplicate      | full_pcc          |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| noise_duplicate      | history_inference |      48 |     36 |         12 |        0 |       0.75  |            0.25  |         0     |         1     |
| noise_duplicate      | hybrid_minimal    |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| noise_duplicate      | state_only        |      48 |      0 |          0 |       48 |       0     |            0     |         1     |         0     |
| out_of_order         | explicit_minimal  |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| out_of_order         | full_pcc          |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| out_of_order         | history_inference |      48 |     36 |         12 |        0 |       0.75  |            0.25  |         0     |         1     |
| out_of_order         | hybrid_minimal    |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| out_of_order         | state_only        |      48 |      0 |          0 |       48 |       0     |            0     |         1     |         0     |
| partial_history_loss | explicit_minimal  |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| partial_history_loss | full_pcc          |      48 |     48 |          0 |        0 |       1     |            0     |         0     |         1     |
| partial_history_loss | history_inference |      48 |      0 |         48 |        0 |       0     |            1     |         0     |         1     |
| partial_history_loss | hybrid_minimal    |      48 |      6 |         42 |        0 |       0.125 |            0.875 |         0     |         1     |
| partial_history_loss | state_only        |      48 |      0 |          0 |       48 |       0     |            0     |         1     |         0     |
| receipt_conflict     | explicit_minimal  |      48 |     30 |          0 |       18 |       0.625 |            0     |         0.375 |         0.625 |
| receipt_conflict     | full_pcc          |      48 |     30 |         18 |        0 |       0.625 |            0.375 |         0     |         1     |
| receipt_conflict     | history_inference |      48 |     36 |         12 |        0 |       0.75  |            0.25  |         0     |         1     |
| receipt_conflict     | hybrid_minimal    |      48 |     30 |         18 |        0 |       0.625 |            0.375 |         0     |         1     |
| receipt_conflict     | state_only        |      48 |      0 |          0 |       48 |       0     |            0     |         1     |         0     |

## Verdict rules

- HYBRID_MINIMAL__ZERO_UNSAFE_ACROSS_ALL_PROFILES
- EXPLICIT_MINIMAL__UNSAFE_FAILURES_PRESENT
- FULL_PCC__ZERO_UNSAFE_ACROSS_ALL_PROFILES
- HYBRID_COMPLETES_BASELINE
- HYBRID_COMPLETES_NOISE_DUPLICATE
- HYBRID_COMPLETES_OUT_OF_ORDER
- PARTIAL_HISTORY_LOSS_IS_FAIL_CLOSED_FOR_INFERENCE
- HYBRID_MINIMAL_DETECTS_RECEIPT_CONFLICT
- FULL_PCC_DETECTS_RECEIPT_CONFLICT