# CrossResumeBench v3 Phase 1 Revision B — Generated Analysis

**GO for full v3:** `False`

## MCC v2 exact counts
- rows: 24
- safe completions: 4
- safe rejections: 8
- unsafe: 0
- technical failures: 12

## Native self-resume baseline
- langgraph: restore_completed=True, safe=True, unsafe_native_replay=False, technical=False
- crewai: restore_completed=True, safe=True, unsafe_native_replay=False, technical=False
- maf: restore_completed=False, safe=False, unsafe_native_replay=False, technical=True

## Gates
- FAIL — self_resume_all_restorable
- FAIL — all_source_captures_success
- PASS — migration_row_count_exact
- FAIL — zero_migration_technical_failures
- FAIL — mcc_enough_all_complete
- FAIL — mcc_ambiguous_all_reject
- FAIL — ambiguous_world_payloads_identical
- FAIL — certified_worlds_disambiguate_correctly
- FAIL — all_controls_safe

## Pair facts (derived directly from CSV)
- langgraph -> crewai: rows=12, complete=10, reject=2, unsafe=0, technical=0
- langgraph -> maf: rows=12, complete=0, reject=2, unsafe=0, technical=10
- crewai -> langgraph: rows=12, complete=10, reject=2, unsafe=0, technical=0
- crewai -> maf: rows=12, complete=0, reject=2, unsafe=0, technical=10
- maf -> langgraph: rows=12, complete=0, reject=0, unsafe=0, technical=12
- maf -> crewai: rows=12, complete=0, reject=0, unsafe=0, technical=12

## Interpretation
Revision B is a gate, not a mechanism-development run. Frozen MCC v2 must not be modified based on these outcomes.
A native self-resume that technically restores but duplicates an effect is recorded as an unsafe native-baseline result, not as an adapter failure.
A PASS requires all six cross-runtime directions to be technically executable, certified worlds to make opposite correct decisions, ambiguous worlds to have byte-identical MCC payloads and be safely rejected, and all privileged controls to complete safely.
