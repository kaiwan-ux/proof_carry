# PortaFlow PCC v0 — Ablation Evidence Summary

Total configured rows: **216**
Valid native target rows: **216**
Technical-failure rows: **0**

## Safe Continuation Rate

- **state_only**: 0/36 = 0.0%
- **state_history**: 6/36 = 16.7%
- **plus_control_frontier**: 18/36 = 50.0%
- **plus_pending_obligations**: 24/36 = 66.7%
- **plus_effect_receipts**: 30/36 = 83.3%
- **full_pcc_v0**: 36/36 = 100.0%

## Failure taxonomy

- **COMPLETED_STEP_REPLAYED**: 72
- **PARALLEL_DEPENDENCY_LOST**: 30
- **DUPLICATE_EXTERNAL_EFFECT**: 24
- **HUMAN_APPROVAL_LOST**: 18
- **BRANCH_DECISION_LOST**: 12
- **REQUIRED_STEP_SKIPPED**: 12
- **WRONG_TERMINATION**: 12
- **LOOP_PROGRESS_LOST**: 12
- **RETRY_STATE_LOST**: 6

## Interpretation rule

This deterministic ablation asks which portable semantic components are sufficient for the six declared workflow classes at safe migration boundaries. It does not prove arbitrary process migration or universal coverage of all agent workflows. Full PCC v0 is the proposed mechanism in this experiment; unlike the earlier diagnostic upper bound, it contains no source-native checkpoint blob.
