# PortaFlow PCC v3 True Held-out Generalization Results

Native rows: 480
Technical failures: 0

## Condition summary

| condition               |   cases |   safe |   rejected |   unsafe |   mean_bytes |   safe_rate |   rejection_rate |   unsafe_rate |
|:------------------------|--------:|-------:|-----------:|---------:|-------------:|------------:|-----------------:|--------------:|
| explicit_minimal        |      60 |     60 |          0 |        0 |        749   |         1   |              0   |           0   |
| explicit_minus_receipts |      60 |     30 |          0 |       30 |        568   |         0.5 |              0   |           0.5 |
| full_pcc                |      60 |     60 |          0 |        0 |       1446.5 |         1   |              0   |           0   |
| history_inference       |      60 |     36 |         24 |        0 |        897.4 |         0.6 |              0.4 |           0   |
| hybrid_minimal          |      60 |     60 |          0 |        0 |       1078.4 |         1   |              0   |           0   |
| hybrid_minus_receipts   |      60 |     36 |         24 |        0 |        897.4 |         0.6 |              0.4 |           0   |
| raw_history             |      60 |      0 |          0 |       60 |        897.4 |         0   |              0   |           1   |
| state_only              |      60 |      0 |          0 |       60 |        307.1 |         0   |              0   |           1   |

## Verdict rules

- HYBRID_MINIMAL_GENERALIZES_TO_TRUE_HOLDOUT
- EXPLICIT_MINIMAL_GENERALIZES_TO_TRUE_HOLDOUT
- HISTORY_INFERENCE_REMAINS_CONSERVATIVE

**Candidates were frozen before this hold-out run. Do not tune them after seeing these results and still call this a hold-out test.**