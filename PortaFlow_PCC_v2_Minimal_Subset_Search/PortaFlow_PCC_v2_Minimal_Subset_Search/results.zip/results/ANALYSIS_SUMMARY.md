# PortaFlow PCC v2 Minimal-Subset Search Results

Stage-A subset/workflow rows: 1024
Native confirmation rows: 384
Technical failures: 0

## Stage-A minimal candidates

{
  "explicit_minimal": {
    "inference_mode": "explicit",
    "subset_key": "frontier+obligations+receipts+contract",
    "components": "frontier,obligations,receipts,contract",
    "component_count": 4,
    "cases": 8,
    "safe_completions": 8,
    "rejections": 0,
    "unsafe_violations": 0,
    "safe_rate": 1.0,
    "rejection_rate": 0.0,
    "unsafe_rate": 0.0,
    "mean_capsule_bytes": 630.25
  },
  "hybrid_minimal": {
    "inference_mode": "hybrid",
    "subset_key": "history+receipts",
    "components": "history,receipts",
    "component_count": 2,
    "cases": 8,
    "safe_completions": 8,
    "rejections": 0,
    "unsafe_violations": 0,
    "safe_rate": 1.0,
    "rejection_rate": 0.0,
    "unsafe_rate": 0.0,
    "mean_capsule_bytes": 911.75
  },
  "component_vocabulary": [
    "progress",
    "history",
    "frontier",
    "obligations",
    "receipts",
    "contract"
  ],
  "search_space_size": 64,
  "workflow_count": 8
}

## Native condition summary

| condition                    |   cases |   safe |   rejected |   unsafe |   mean_bytes |   safe_rate |   rejection_rate |   unsafe_rate |
|:-----------------------------|--------:|-------:|-----------:|---------:|-------------:|------------:|-----------------:|--------------:|
| explicit_minimal             |      48 |     48 |          0 |        0 |      625.25  |         1   |              0   |             0 |
| full_pcc                     |      48 |     48 |          0 |        0 |     1229.12  |         1   |              0   |             0 |
| history_inference            |      48 |     24 |         24 |        0 |      763.375 |         0.5 |              0.5 |             0 |
| hybrid_minimal               |      48 |     48 |          0 |        0 |      906.75  |         1   |              0   |             0 |
| hybrid_minimal_minus_history |      48 |      0 |          0 |       48 |      409.125 |         0   |              0   |             1 |
| raw_history                  |      48 |      0 |          0 |       48 |      763.375 |         0   |              0   |             1 |
| receipts_only                |      48 |      0 |          0 |       48 |      409.125 |         0   |              0   |             1 |
| state_only                   |      48 |      0 |          0 |       48 |      265.75  |         0   |              0   |             1 |

## Conservative interpretation

- HYBRID_MINIMAL_CONFIRMED_ON_NATIVE_HOLDOUT_MATRIX
- EXPLICIT_MINIMAL_CONFIRMED_ON_NATIVE_HOLDOUT_MATRIX
- COMPACT_HYBRID_MATCHES_FULL_PCC_ON_TESTED_CASES
- HISTORY_INFERENCE_IS_SAFE_BUT_COVERAGE_LIMITED

**Do not generalize minimality beyond the tested component vocabulary, workflows, migration boundaries, and framework versions.**