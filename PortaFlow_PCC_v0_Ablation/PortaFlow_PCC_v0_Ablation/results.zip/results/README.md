# Results folder

This folder intentionally ships empty except for placeholders. Run `run_pcc_v0.ps1` (Windows), `run_pcc_v0.bat`, or `run_pcc_v0.sh` to create fresh evidence.

Do not place manually edited result files here before a run.
