# PCC v1 Generalization + Minimality Results

Total configured rows: 432
Technical failures: 0

## Condition summary

| condition             |   cases |   safe_completions |   rejections |   unsafe_violations |   mean_ambiguities |   mean_inferred_fields |   mean_capsule_bytes |   safe_completion_rate |   rejection_rate |   unsafe_violation_rate |
|:----------------------|--------:|-------------------:|-------------:|--------------------:|-------------------:|-----------------------:|---------------------:|-----------------------:|-----------------:|------------------------:|
| full_pcc_v1           |      48 |                 48 |            0 |                   0 |                0   |                  0     |             1215.38  |                   1    |              0   |                    0    |
| history_inference     |      48 |                 24 |           24 |                   0 |                0.5 |                  4.625 |              751.125 |                   0.5  |              0.5 |                    0    |
| pcc_minus_contract    |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |             1135.5   |                   1    |              0   |                    0    |
| pcc_minus_frontier    |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |             1153.5   |                   1    |              0   |                    0    |
| pcc_minus_history     |      48 |                 48 |            0 |                   0 |                0   |                  0     |              718     |                   1    |              0   |                    0    |
| pcc_minus_obligations |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |             1141     |                   1    |              0   |                    0    |
| pcc_minus_receipts    |      48 |                 36 |            0 |                  12 |                0.5 |                  4.625 |             1073.5   |                   0.75 |              0   |                    0.25 |
| raw_history           |      48 |                  0 |            0 |                  48 |                0   |                  0     |              751.125 |                   0    |              0   |                    1    |
| state_only            |      48 |                  0 |            0 |                  48 |                0   |                  0     |              253.75  |                   0    |              0   |                    1    |

## Leave-one-out minimality

| condition             |   cases |   safe_completions |   rejections |   unsafe_violations |   mean_ambiguities |   mean_inferred_fields |   mean_capsule_bytes |   safe_completion_rate |   rejection_rate |   unsafe_violation_rate |   drop_vs_full |
|:----------------------|--------:|-------------------:|-------------:|--------------------:|-------------------:|-----------------------:|---------------------:|-----------------------:|-----------------:|------------------------:|---------------:|
| pcc_minus_contract    |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |               1135.5 |                   1    |                0 |                    0    |           0    |
| pcc_minus_frontier    |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |               1153.5 |                   1    |                0 |                    0    |           0    |
| pcc_minus_history     |      48 |                 48 |            0 |                   0 |                0   |                  0     |                718   |                   1    |                0 |                    0    |           0    |
| pcc_minus_obligations |      48 |                 48 |            0 |                   0 |                0.5 |                  4.625 |               1141   |                   1    |                0 |                    0    |           0    |
| pcc_minus_receipts    |      48 |                 36 |            0 |                  12 |                0.5 |                  4.625 |               1073.5 |                   0.75 |                0 |                    0.25 |           0.25 |

## Conservative verdict

- PCC_V1_GENERALIZATION_SUPPORTED_ON_HOLDOUT_SUITE
- PCC_VALUE_MAY_BE_SAFE_COVERAGE_OVER_CONSERVATIVE_INFERENCE

**Do not claim universal portability or mathematical minimality from this experiment alone.**