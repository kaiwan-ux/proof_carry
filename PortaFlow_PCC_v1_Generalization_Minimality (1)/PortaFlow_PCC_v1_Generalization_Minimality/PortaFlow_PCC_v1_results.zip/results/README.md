# Results directory

This directory intentionally starts clean. Real experimental outputs are generated only when `run_pcc_v1.ps1`, `.bat`, or `.sh` is executed on the user's machine with the native framework dependencies installed.

Do not treat any development self-test as research evidence.
