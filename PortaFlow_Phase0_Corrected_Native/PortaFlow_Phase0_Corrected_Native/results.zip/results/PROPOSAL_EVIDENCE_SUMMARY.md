# PortaFlow Corrected Phase-0 — Native Evidence Summary

Total configured rows: **54**
Valid native target runs: **54**
Technical-failure rows: **0**

## Safe Continuation Rate (descriptive; no CI)

- **naive_state**: 0/18 = 0.0%
- **native_semantic**: 18/18 = 100.0%
- **state_history**: 12/18 = 66.7%

## Failure taxonomy

- **COMPLETED_STEP_REPLAYED**: 18
- **DUPLICATE_EXTERNAL_EFFECT**: 12
- **RETRY_STATE_LOST**: 6
- **HUMAN_APPROVAL_LOST**: 6

## Gate decision

**PRELIMINARY GO:** naive_state passed 0/18 core cases. Inspect failure mechanisms before designing PCC.

## Claim boundary

These are native framework executions at declared migration-safe boundaries. They test whether selected state representations are sufficient to continue equivalent workflows in another runtime. They do **not** yet prove arbitrary mid-instruction process migration, universal framework incompatibility, or PortaFlow/PCC effectiveness. `native_semantic` is a diagnostic privileged upper bound, not the proposed method.
